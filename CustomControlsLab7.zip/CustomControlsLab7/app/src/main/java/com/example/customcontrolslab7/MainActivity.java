package com.example.customcontrolslab7;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    Button btnColored, btnRound, btnBorder, btnToast, btnDialog, btnGradient, btnSelectorShape;
    ImageButton emoji1, emojiBg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnColored = findViewById(R.id.btnColored);
        btnRound = findViewById(R.id.btnRound);
        btnBorder = findViewById(R.id.btnBorder);
        btnGradient = findViewById(R.id.btnGradient);
        btnSelectorShape = findViewById(R.id.btnSelectorShape);

        emoji1 = findViewById(R.id.emoji1);
        emojiBg = findViewById(R.id.emojiBg);

        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);
        View[] toggleViews = {
                btnColored, btnBorder, btnSelectorShape,
                emoji1, emojiBg
        };

        for (View v : toggleViews) {
            v.setOnClickListener(view -> {
                view.setSelected(!view.isSelected()); // giữ trạng thái
            });
        }
        btnToast.setOnClickListener(v -> {
            LayoutInflater inflater = getLayoutInflater();
            View view = inflater.inflate(R.layout.custom_toast, null);

            Toast toast = new Toast(getApplicationContext());
            toast.setView(view);
            toast.setDuration(Toast.LENGTH_LONG);
            toast.show();
        });
        btnDialog.setOnClickListener(v -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.custom_dialog, null);
            builder.setView(dialogView);

            AlertDialog dialog = builder.create();
            dialog.show();

            EditText edtUser = dialogView.findViewById(R.id.edtUser);
            EditText edtPass = dialogView.findViewById(R.id.edtPass);
            Button btnOK = dialogView.findViewById(R.id.btnOK);
            Button btnCancel = dialogView.findViewById(R.id.btnCancel);

            btnOK.setOnClickListener(v2 -> {
                Toast.makeText(this,
                        "User: " + edtUser.getText(),
                        Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            btnCancel.setOnClickListener(v2 -> dialog.dismiss());
        });

    }
}
